from tplt import tplt as t
import keyboard
import numpy as np
import matplotlib.pyplot as plt
def draw_paddle(y):
    plt.plot([-20 , -20] , [y + 3 , y - 3] , color = 'b')
def draw_opposing_paddle(y):
    plt.plot([20 , 20] , [y + 3 , y - 3] , color = 'r')
def table():
    plt.plot([-20 , 20] , [-10 , -10] , color = 'k')
    plt.plot([-20 , 20] , [10 , 10] , color = 'k')
    plt.plot([ 0 , 0 ] , [-5 , 5] , color = (.8 , .8 , .8))
def score(a , x , color = 'k'):
    for i in range(a):
        plt.plot(x + i , 12 , '.', color = color)
def reset():
    t.goto(0 , 0)
    turn = np.random.randint(4 , 6)
    if turn == 4:
        t.setheading(np.random.randint(135 , 226))
    if turn == 5:
        t.setheading(np.random.randint(-45 , 46))
speed = float(input('Enter speed, 1 is the default:'))
ball = [0 , 0 , 0]
pscore = 0
oscore = 0
paddle = 0.0
opposing_paddle = 0.0
color = 'k'
t.setheading(np.random.randint(0 , 360))
while True:
    plt.pause(1 / 60)
    plt.cla()
    plt.axis('equal')
    t.forward(speed)
    score(pscore , -20 , color = 'b')
    score(oscore , 0 , color = 'r')
    draw_paddle(paddle)
    draw_opposing_paddle(opposing_paddle)
    table()
    t.down()
    t.circle(1 , color = color)
    t.up()
    ball = t.locate()
    if keyboard.is_pressed('up'):
        paddle += speed
        draw_paddle(paddle)
    if keyboard.is_pressed('down'):
        paddle -= speed
        draw_paddle(paddle)
    if ball[1] > opposing_paddle:
        opposing_paddle += speed / 2
        draw_opposing_paddle(opposing_paddle)
    if ball[1] < opposing_paddle:
        opposing_paddle -= speed / 2
        draw_opposing_paddle(opposing_paddle)
    if ball[0] < speed - 19 and (paddle - 3) < ball[1] < (paddle + 3):
        t.setheading(np.random.randint(-20 , 21) + 180 - ball[2])
        color = 'b'
    if ball[0] > 19 - speed and (opposing_paddle - 3) < ball[1] < (opposing_paddle + 3):
        t.setheading(np.random.randint(-20 , 21) + 180 - ball[2])
        color = 'r'
    if ball[1] < speed - 9 or ball[1] > 9 - speed and speed - 19 < ball[0] < 19 - speed:
        t.setheading(np.random.randint(-20 , 21) - ball[2])
    if ball[0] < - 20:
        reset()
        oscore += 1
        color = 'g'
    if ball[0] > 20:
        reset()
        pscore += 1
        color = 'g'
    if ball[1] > 10 or ball[1] < -10:
        reset()
plt.show()